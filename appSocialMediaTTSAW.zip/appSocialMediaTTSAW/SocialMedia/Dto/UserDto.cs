﻿namespace SocialMedia.Dto
{
    public class UserDto
    {
        public string Id { get; set; }
        public string Fullname { get; set; }
        public string Email { get; set; }
        public string Token { get; set; }

    }
}
