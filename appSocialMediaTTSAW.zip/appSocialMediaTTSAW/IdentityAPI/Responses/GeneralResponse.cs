﻿namespace IdentityAPI.Responses
{
    public record GeneralResponse(bool Flag, string Message = null!);

}
