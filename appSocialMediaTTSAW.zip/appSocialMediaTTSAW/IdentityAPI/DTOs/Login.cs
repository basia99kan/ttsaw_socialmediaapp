﻿
namespace IdentityAPI.DTOs
{
    public class Login : AccountBase
    {

    }
}