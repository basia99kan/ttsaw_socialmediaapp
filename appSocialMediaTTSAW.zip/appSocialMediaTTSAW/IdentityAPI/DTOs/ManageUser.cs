﻿
namespace IdentityAPI.DTOs
{
    public class ManageUser
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
        public int UserId { get; set; }
        public string? Role { get; set; }

    }
}
