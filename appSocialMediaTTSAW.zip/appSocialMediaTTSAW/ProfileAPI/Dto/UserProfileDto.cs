﻿namespace ProfileAPI.Dto
{
    public class UserProfileDto
    {
        public string Description { get; set; } 
        public string Hobby { get; set; }        
        public string Location { get; set; }    
        public string ProfilePictureUrl { get; set; } 
        public string Website { get; set; }    
    }
}
