﻿namespace ProfileAPI.Helpers
{
    public static class Constants
    {
        public static string Admin { get; } = "Admin";
        public static string User { get; } = "User";
    }
}
